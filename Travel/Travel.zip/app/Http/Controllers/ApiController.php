<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Illuminate\Support\MessageBag;
use App\Account;
use App\Group;
use App\MemberGroup;
use App\Place;
use App\Event;
use App\Festival;
use App\Discount;
use App\Province;
use App\District;
use DB;
use Image;
use Session;
use Validator;

class ApiController extends Controller
{
    public function getEvents(request $request)
    {
        $events = DB::table('Event')
          ->where('idProvince', $request->idProvince)
          ->get();

        return \Response::json($events);

    }
}

