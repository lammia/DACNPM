<?php $__env->startSection('content'); ?>
<body>
  <table class="stripe responstable example" width="100%" cellspacing="0" border-collapse: collapse ;> 
    <h3 style="color: #5a738e;" align="center"> USER MANAGEMENT</h3>
    <a href="<?php echo e(url('adduser')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> ADD USER</a><br>
    
    <div>
      <?php if(Session::has('flash_message0')): ?>
      <div class="alert alert-danger form-feedback" role="alert">
        <?php echo Session::get('flash_message0'); ?>

      </div>
      <?php endif; ?>
      <?php if(Session::has('flash_message1')): ?>
      <div class="alert alert-success form-feedback" role="alert">
        <?php echo Session::get('flash_message1'); ?>

      </div>
      <?php endif; ?>
      <?php if(Session::has('flash_message')): ?>
      <div class="alert alert-success form-feedback" role="alert">
        <?php echo Session::get('flash_message'); ?>

      </div>
      <?php endif; ?>
    </div>

    <thead>
      <tr align="center" >
        <th style="text-align: center">ID</th>      
        <th style="text-align: center">Name</th>
        <th style="text-align: center">Email</th>
        <th style="text-align: center">Adress</th>
        <th style="text-align: center">Phone number</th>      
        <th style="text-align: center">Image</th>
        <th style="text-align: center; width: 24%;">Action</th> 
      </tr>
    </thead>

    <tbody>
    <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
     <td><?php echo e($item->idAccount); ?></td>
     <td><?php echo e($item->nameAccount); ?></td>
     <td><?php echo e($item->email); ?></td>
     <td><?php echo e($item->districts->name); ?>, <?php echo e($item->provinces->name); ?></td>
     <td><?php echo e($item->phone); ?></td>
     <td><img class="img-rounded img-responsive" width="104" height="90" src="<?php echo e(asset('upload/'.$item->img)); ?>"></td>
     <td>
        <a href="<?php echo e(url('EditUser/'.$item->idAccount)); ?>" class="btn btn-success btn-responsive"><i class="fa fa-edit"></i> Edit</a>

        <a href="<?php echo e(url('/DeleteUser/'.$item->idAccount)); ?>" class ="btn btn-danger btn-responsive" 
            onclick="return confirmAction()" ><i class="fa fa-trash-o"></i> Delete
        </a>
     </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </tbody>
    </table>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>