<!DOCTYPE>
<html>
<head>
	<meta charset="UTF-8">
	<link href="css/login.css" rel="stylesheet"/>
</head>
<body>
	<form action="<?php echo e(url('login')); ?>" method="post">
		<h1>Login</h1>
  		      
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
                
      <input placeholder="Email" type="Email"" name="email" required="" value="<?php echo e(old('email')); ?>" class="text">
          
      <?php if($errors->has('email')): ?>
      <p style="color:red; margin-left: 20px" ><?php echo e($errors->first('email')); ?></p>
      <?php endif; ?>    
      
      <input placeholder="Password" type="password" name="password" required="">
          
      <?php if($errors->has('password')): ?>
      <p style="color:red; margin-left: 20px"><?php echo e($errors->first('password')); ?></p>
      <?php endif; ?>

      <?php if($errors->has('errorlogin')): ?>
        <div class="alert alert-danger">
          <p style="margin-left: 20px;color:red"><?php echo e($errors->first('errorlogin')); ?></p>
        </div>
      <?php endif; ?>

      <div class="p-container">            
        <input type="submit" value="SIGN IN">
          <?php echo csrf_field(); ?>

        <div class="clear"> </div>
      </div>

</form>

</body>
</html>