<?php $__env->startSection('content'); ?>
<body>
  <h3 style="color: #5a738e" align="center"> EDIT USER</h3><br>
  <form action="/updateUser/<?php echo e($user->idAccount); ?>" method="POST" name="form" style="margin-left: 150px" enctype="multipart/form-data">
  <input type="hidden" name="_token"  value="<?php echo csrf_token(); ?>">
  <div>
    <?php if(Session::has('flash_message1')): ?>
      <div class="alert alert-success form-feedback" role="alert">
        <?php echo Session::get('flash_message1'); ?>

      </div>
    <?php endif; ?>
  </div>

    <div class="form-group">
      <label class="control-label col-sm-2">ID:</label>
      <input type="text" disabled="disabled" class="form-control" id="formGroupExampleInput" name="id" value="<?php echo e($user->idAccount); ?>">
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2">Group:</label>
     <select name ="group" class="input-large form-control">

        <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($value->idGroup == $member->idGroup): ?>
          <option selected="" value="<?php echo e($value->idGroup); ?>"><?php echo e($value->nameGroup); ?></option>
          <?php else: ?>
        <option value="<?php echo e($value->idGroup); ?>"><?php echo e($value->nameGroup); ?></option>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
      </select>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2">Name:</label>
     <input type="text" class="form-control" required="" maxlength="50" id="formGroupExampleInput" name="name" value="<?php echo e($user->nameAccount); ?>">
    </div>
    <?php if($errors->has('errorname')): ?>
      <div style="padding-left: 150px;">
      <p style="color:red"><?php echo e($errors->first('errorname')); ?></p>
      </div>
    <?php endif; ?>

    <div class="form-group">
      <label class="control-label col-sm-2">Email:</label>
      <input type="Email" class="form-control" required="" maxlength="50" id="formGroupExampleInput" name="email" value="<?php echo e($user->email); ?>">
    </div>
    <?php if($errors->has('email')): ?>
      <div style="padding-left: 150px;">
      <p style="color:red"><?php echo e($errors->first('email')); ?></p>
      </div>
    <?php endif; ?>
    <?php if($errors->has('erroremail')): ?>
      <div style="padding-left: 150px;">
      <p style="color:red"><?php echo e($errors->first('erroremail')); ?></p>
      </div>
    <?php endif; ?>

    <div class="form-group">
      <label class="control-label col-sm-2">Phone number:</label>
      <input type="text" class="form-control" required="" minlength="10" maxlength="11" id="formGroupExampleInput" name="phone" value="<?php echo e($user->phone); ?>">
    </div>
    <?php if($errors->has('phone')): ?>
      <div style="padding-left: 150px;">
      <p style="color:red"><?php echo e($errors->first('phone')); ?></p>
      </div>
    <?php endif; ?>

    <div class="form-group">
      <label class="control-label col-sm-2">Province:</label>
      <select class="input-large form-control selectProvince" name="province" id="selectProvince">
          <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($value->idProvince == $user->idProvince): ?>
              <option selected="" value="<?php echo e($value->idProvince); ?>"><?php echo e($value->name); ?></option>
            <?php else: ?>
              <option value="<?php echo e($value->idProvince); ?>"><?php echo e($value->name); ?></option>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2">District:</label>
      <select class="input-large form-control selectDistrict" name="province" id="selectDistrict">
          <?php $__currentLoopData = $district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($value->idDistrict == $user->idDistrict): ?>
              <option selected="" value="<?php echo e($value->idDistrict); ?>"><?php echo e($value->name); ?></option>
            <?php else: ?>
              <option value="<?php echo e($value->idDistrict); ?>"><?php echo e($value->name); ?></option>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2">Image:</label>
      <input type="file" class="form-control" id="formGroupExampleInput" name="image" value="<?php echo e($user->img); ?>">
    </div>
    <?php if($errors->has('image')): ?>
      <div style="padding-left: 150px;">
      <p style="color:red"><?php echo e($errors->first('image')); ?></p>
      </div>
    <?php endif; ?>

    <div style="text-align: center; margin-left: -150px; margin-bottom: 10px;" >
      <button style="margin-top: 15px" type="submit" class="btn btn-success">Save</button>
    </div>

  </form>

  <form action="/editpass/<?php echo e($user->idAccount); ?>" method="POST" name="formuser" style="margin-left: 150px" enctype="multipart/form-data">
  <input type="hidden" name="_token"  value="<?php echo csrf_token(); ?>">

  <div>
    <?php if(Session::has('flash_message3')): ?>
      <div class="alert alert-success form-feedback" role="alert">
        <?php echo Session::get('flash_message3'); ?>

      </div>
    <?php endif; ?>
    <?php if(Session::has('flash_message4')): ?>
      <div class="alert alert-danger form-feedback" role="alert">
        <?php echo Session::get('flash_message4'); ?>

      </div>
    <?php endif; ?>
  </div>

  <div class="form-group">
      <label class="control-label col-sm-2">New Password:</label>
      <input type="Password" required="" minlength="8" maxlength="30" class="form-control" id="formGroupExampleInput" name="password">
  </div>
    <?php if($errors->has('password')): ?>
      <div style="padding-left: 150px;">
      <p style="color:red"><?php echo e($errors->first('password')); ?></p>
      </div>
    <?php endif; ?>

  <div class="form-group">
      <label class="control-label col-sm-2">Confirm Password:</label>
      <input type="Password" required="" class="form-control" minlength="8" maxlength="30" id="formGroupExampleInput" name="cfpassword">
  </div>
    <?php if($errors->has('cfpassword')): ?>
      <div style="padding-left: 150px;">
      <p style="color:red"><?php echo e($errors->first('cfpassword')); ?></p>
      </div>
    <?php endif; ?>

  <div style="text-align: center; margin-left: -150px; margin-top: 5px;" >
      <button type="submit" class="btn btn-success">Save</button>
  </div>

  </form>
  </body>
  <?php $__env->stopSection(); ?>




<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>