<?php $__env->startSection('content'); ?>

<body> 

  <table class="table table-hover table-bordered responstable example" style="border-collapse:collapse;">
    <h3 style="color: #5a738e;" align="center"> TOUR MANAGEMENT</h3>
      <a href="<?php echo e(url('addtour')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> ADD TOUR</a>
    <div>
      <?php if(Session::has('flash_message6')): ?>
      <div class="alert alert-success form-feedback" role="alert">
        <?php echo Session::get('flash_message6'); ?>

      </div>
      <?php endif; ?>
      <?php if(Session::has('flash_message5')): ?>
      <div class="alert alert-success form-feedback" role="alert">
        <?php echo Session::get('flash_message5'); ?>

      </div>
    <?php endif; ?> 
    </div>

    <thead>
      <tr align="center" >
        <th style="text-align: center">ID</th>      
        <th style="text-align: center">People</th>
        <th style="text-align: center">List Place</th>
        <th style="text-align: center">Money</th>
        <th style="text-align: center">Time begin</th>
        <th style="text-align: center">Time end</th>
        <!-- <th style="text-align: center">Rating</th> -->  
        <th style="text-align: center; width: 24%;">Action</th> 
      </tr>
    </thead>

    <tbody>
    <?php $__currentLoopData = $tour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
     <td><?php echo e($item->idSchedule); ?></td>
     <td><?php echo e($item->amountOfPeople); ?></td>
     <td></td>
     <td><?php echo e($item->money); ?></td>
     <td><?php echo e($item->timeBegin); ?></td>
     <td><?php echo e($item->timeEnd); ?></td>
     <td>
      <a href="" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
      <a href="" class ="btn btn-danger" 
          onclick="return confirmAction()" ><i class="fa fa-trash-o"></i> Delete
      </a>
     </td>
     </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

  </table>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>