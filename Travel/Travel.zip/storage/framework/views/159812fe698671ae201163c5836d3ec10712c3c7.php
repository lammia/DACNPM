<?php $__env->startSection('content'); ?>
<body>
  <table class="table table-hover table-bordered responstable example" style="border-collapse:collapse;">
    <h3 style="color: #5a738e;" align="center"> FESTIVAL MANAGEMENT</h3>
      <a href="<?php echo e(url('addfestival')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> ADD FESTIVAL</a><br>
    <div>
      <?php if(Session::has('flash_message12')): ?>
      <div class="alert alert-success form-feedback" role="alert">
        <?php echo Session::get('flash_message12'); ?>

      </div>
      <?php endif; ?>
      <?php if(Session::has('flash_message14')): ?>
      <div class="alert alert-success form-feedback" role="alert">
        <?php echo Session::get('flash_message14'); ?>

      </div>
      <?php endif; ?>  
    </div>

    <thead>
      <tr align="center" >
        <th style="text-align: center">ID</th>      
        <th style="text-align: center">Name</th>
        <th style="text-align: center">Time begin</th>
        <th style="text-align: center">Time end</th>
        <th style="text-align: center">Place</th>
        <th style="text-align: center">Image</th>
        <th style="text-align: center; width: 24%;">Action</th> 
      </tr>
    </thead>

    <tbody>
    <?php $__currentLoopData = $festival; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
     <td><?php echo e($item->idFestival); ?></td>
     <td><?php echo e($item->nameFestival); ?></td>
     <td><?php echo e($item->timeBeginFestival); ?></td>
     <td><?php echo e($item->timeEndFestival); ?></td>
     <td><?php echo e($item->places->namePlace); ?></td>
     <td><img class="img-rounded img-responsive" width="104" height="90" src="<?php echo e(asset('upload/'.$item->img)); ?>"></td>
     <td>
      <a href="<?php echo e(url('EditFestival/'.$item->idFestival)); ?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
      <a href="<?php echo e(url('/DeleteFestival/'.$item->idFestival)); ?>" class ="btn btn-danger" 
            onclick="return confirmAction()" ><i class="fa fa-trash-o"></i> Delete
        </a> 
     </td>
     </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

  </table>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>