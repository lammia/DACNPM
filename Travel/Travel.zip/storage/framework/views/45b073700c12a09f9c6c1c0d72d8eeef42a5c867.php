<?php $__env->startSection('content'); ?>

<body> 

  <table class="table table-hover table-bordered responstable example" style="border-collapse:collapse;">
    <h3 style="color: #5a738e;" align="center"> PLACE MANAGEMENT</h3>
      <a href="<?php echo e(url('addplace')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> ADD PLACE</a>
      <a href="<?php echo e(url('typeplace')); ?>" class="btn btn-primary"><i class="fa fa-cog"></i> TYPE PLACE</a><br>
    <div>
      <?php if(Session::has('flash_message6')): ?>
      <div class="alert alert-success form-feedback" role="alert">
        <?php echo Session::get('flash_message6'); ?>

      </div>
      <?php endif; ?>
      <?php if(Session::has('flash_message5')): ?>
      <div class="alert alert-success form-feedback" role="alert">
        <?php echo Session::get('flash_message5'); ?>

      </div>
    <?php endif; ?> 
    </div>

    <thead>
      <tr align="center" >
        <th style="text-align: center">ID</th>      
        <th style="text-align: center">Name</th>
        <th style="text-align: center">Type</th>
        <th style="text-align: center">Money</th>
        <th style="text-align: center">Adress</th>
        <!-- <th style="text-align: center">Rating</th> -->
        <th style="text-align: center">Image</th>  
        <th style="text-align: center; width: 24%;">Action</th> 
      </tr>
    </thead>

    <tbody>
    <?php $__currentLoopData = $place; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
     <td><?php echo e($item->idPlace); ?></td>
     <td><?php echo e($item->namePlace); ?></td>
     <td><?php echo e($item->type->nameType); ?></td>
     <td><?php echo e($item->MoneyToTravel); ?></td>
     <td><?php echo e($item->address); ?></td>
     <td><img class="img-rounded img-responsive" width="104" height="90" src="<?php echo e(asset('upload/'.$item->img)); ?>"></td>
     <td>
      <a href="<?php echo e(url('EditPlace/'.$item->idPlace)); ?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
      <a href="<?php echo e(url('/DeletePlace/'.$item->idPlace)); ?>" class ="btn btn-danger" 
          onclick="return confirmAction()" ><i class="fa fa-trash-o"></i> Delete
      </a>
     </td>
     </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

  </table>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>