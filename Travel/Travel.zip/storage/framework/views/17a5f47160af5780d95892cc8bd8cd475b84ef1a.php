<?php $__env->startSection('content'); ?>
<body>
  <table class="table table-hover table-bordered responstable example" style="border-collapse:collapse;">
    <h3 style="color: #5a738e;" align="center"> DISCOUNT MANAGEMENT</h3>
      <a href="<?php echo e(url('addDiscount')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> ADD DISCOUNT</a><br>
    <div>
      <?php if(Session::has('flash_message20')): ?>
      <div class="alert alert-success form-feedback" role="alert">
        <?php echo Session::get('flash_message20'); ?>

      </div>
      <?php endif; ?> 
      <?php if(Session::has('flash_message21')): ?>
      <div class="alert alert-success form-feedback" role="alert">
        <?php echo Session::get('flash_message21'); ?>

      </div>
      <?php endif; ?> 
    </div>

    <thead>
      <tr align="center" >
        <th style="text-align: center">ID</th>
        <th style="text-align: center">Place</th>      
        <th style="text-align: center">Percent Discount</th>
        <th style="text-align: center">Time begin</th>
        <th style="text-align: center">Time end</th>
        <th style="text-align: center">Status</th>
        <th style="text-align: center; width: 24%;">Action</th> 
      </tr>
    </thead>

    <tbody>
    <?php $__currentLoopData = $discount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
     <td><?php echo e($item->idDiscount); ?></td>
     <td><?php echo e($item->places->namePlace); ?></td>
     <td><?php echo e($item->percentDiscount); ?>%</td>
     <td><?php echo e($item->timeBeginDiscount); ?></td>
     <td><?php echo e($item->timeEndDiscount); ?></td>
     <?php if((strtotime($item->timeEndDiscount) - strtotime($now)) <= 0): ?>
      <td>Finished</td>
      <td>
      <a href="<?php echo e(url('EditDiscount/'.$item->idDiscount)); ?>" class="btn btn-success" disabled=""><i class="fa fa-edit"></i> Edit</a>
      <a href="<?php echo e(url('/DeleteDiscount/'.$item->idDiscount)); ?>" class ="btn btn-danger" 
            onclick="return confirmAction()" ><i class="fa fa-trash-o"></i> Delete
        </a> 
     </td>
     <?php else: ?>
      <td>Doing</td>
      <td>
      <a href="<?php echo e(url('EditDiscount/'.$item->idDiscount)); ?>" class="btn btn-success"><i class="fa fa-edit"></i> Edit</a>
      <a href="<?php echo e(url('/DeleteDiscount/'.$item->idDiscount)); ?>" class ="btn btn-danger" 
            onclick="return confirmAction()" ><i class="fa fa-trash-o"></i> Delete
        </a> 
     </td>
     <?php endif; ?>
     </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

  </table>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>